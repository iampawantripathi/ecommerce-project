const express = require('express');
const { celebrate, Joi, Segments } = require('celebrate');

const userController = require('../controllers/userController.js');

const router = express.Router();



router.post(
    '/orders/create',

    celebrate({
        [Segments.BODY]: {
            order_id: Joi.number().required(),
            item_name: Joi.string().required(),
            cost: Joi.number().required(),
            order_date: Joi.date().required(),
            delivery_date: Joi.date().required()
        }
    }),

    userController.createOrder);



router.post(
    '/orders/update',

    celebrate({
        [Segments.QUERY]: {
            order_id: Joi.number().required(),
            delivery_date: Joi.date().required()
        }
    }),

    userController.updateOrder);


router.get(
    '/orders/list',

    celebrate({
        [Segments.QUERY]: {
            date: Joi.date().required()
        }
    }),

    userController.orderList);


router.get(
    '/orders/search',

    celebrate({
        [Segments.QUERY]: {
            order_id: Joi.number().required()
        }
    }),

    userController.searchOrder);


router.get(
    '/orders/delete',

    celebrate({
        [Segments.QUERY]: {
            order_id: Joi.number().required()
        }
    }),

    userController.deleteOrder);


module.exports = router;