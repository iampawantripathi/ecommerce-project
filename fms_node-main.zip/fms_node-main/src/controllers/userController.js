const moment = require('moment');

const { RES, REE } = require('../services/service.js');
const Order = require('../models/mongodb/Order.model.js');

class userController {
    constructor() { }

    /* Function Name: createOrder
       Description: Api For create orders
    */

    async createOrder(req, res) {

        try {

            const { order_id, item_name, cost, order_date, delivery_date } = req.body;

            const orderDate = moment(order_date).format('YYYY-MM-DD');
            const deliveryDate = moment(delivery_date).format('YYYY-MM-DD');

            // Validate duplicate orders based on order_id
            const existingOrder = await Order.findOne({ order_id: order_id });
            if (existingOrder) {
                return REE(res, 'Order already exists.', 400);
            }

            const newOrder = {
                order_id: order_id,
                item_name: item_name,
                cost: cost,
                order_date: orderDate,
                delivery_date: deliveryDate,
            };

            // Save the order to the database

            const result = await Order.create(newOrder);

            if (result) {
                return RES(res, 'Order created successfully', 200);
            } else {
                return REE(res, 'Order not created', 400);
            }

        } catch (error) {
            console.error(error);
            return REE(res, error.message, 500);
        }

    }


    /* Function Name: updateOrder
           Description: Api For update orders
        */

    async updateOrder(req, res) {

        try {

            const { order_id, delivery_date } = req.query;

            const deliveryDate = moment(delivery_date).format('YYYY-MM-DD');

            const result = await Order.findOneAndUpdate(
                { order_id: order_id },
                { delivery_date: deliveryDate }
            );

            if (result) {
                return RES(res, 'Order updated successfully', 200);
            } else {
                return REE(res, 'Order not updated', 400);
            }


        } catch (error) {
            console.error(error);
            return REE(res, error.message, 500);
        }

    }


    /* Function Name: orderList
          Description: Api For orders list
       */

    async orderList(req, res) {

        try {

            const { date } = req.query;

            const orderDate = moment(date).format('YYYY-MM-DD');

            const orders = await Order.find({ order_date: orderDate });

            if (orders) {
                return RES(res, orders, 200);
            } else {
                return REE(res, 'Order not found', 400);
            }


        } catch (error) {
            console.error(error);
            return REE(res, error.message, 500);
        }

    }


    /* Function Name: searchOrder
        Description: Api For search order
     */

    async searchOrder(req, res) {

        try {

            const { order_id } = req.query;

            const order = await Order.findOne({ order_id: order_id });

            if (order) {
                return RES(res, order, 200);
            } else {
                return REE(res, 'Order not found', 400);
            }


        } catch (error) {
            console.error(error);
            return REE(res, error.message, 500);
        }

    }


    /* Function Name: deleteOrder
       Description: Api For delete order
    */

    async deleteOrder(req, res) {

        try {

            const { order_id } = req.query;

            const deleteOrder = await Order.deleteOne({ order_id: order_id });

            if (deleteOrder) {
                return RES(res, 'Order deleted successfully', 200);
            } else {
                return REE(res, 'Order not deleted', 400);
            }


        } catch (error) {
            console.error(error);
            return REE(res, error.message, 500);
        }

    }


}

module.exports = new userController();